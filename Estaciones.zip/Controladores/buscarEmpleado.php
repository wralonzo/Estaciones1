<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion = mysql_connect($host, $usuario, $contraseña);
	mysql_select_db($base, $conexion);

	$res=mysql_query("select * from empleado",$conexion);
	

	$consulta = mysql_query("SELECT codigo, nombre, apellido, direccion, correo, dpi, fecnac FROM empleado", $conexion) OR die ("No se pudo ejecutar la consulta1");
	while ($fila = mysql_fetch_row($consulta)) {
        	    $codigo = $fila[0];
			    $nombre = $fila[1];
			    $apellido = $fila[2];
			    $direccion = $fila[3];
			    $correo = $fila[4];
			    $dpi = $fila[5];
			    $fecnac = $fila[6];

			    $buscar = $_POST['txtBuscar'];


			    	if ($dpi == $buscar) {
			    		?>
					    	<!DOCTYPE html>
					    	<html>
					    		<head>
					    			<title></title>
					    			<link rel="stylesheet" type="text/css" href="../Vistas/css/table.css"/>
					    		</head>
					    		<body>
					    		
					    		<section>
					    			<h1>Busqueda de empleados por DPI</h1>
					    			<button class="button button6" onclick="window.location='http://localhost/proyectosumg/Estaciones/Vistas/empleado.php'">Volver</button>	<br><br>
					    		<table class= "table" border="3" >
									<tr>
										<th>Nombre</th>
										<th>Apellido</th>
										<th>Direccion</th>
										<th>Correo</th>
										<th>Dpi</th>
										<th>Fecha de nacimiento</th>
										</tr>

									<tr>
										
										<td> <?php echo $nombre; ?></td>
										<td> <?php echo $apellido; ?></td>
										<td> <?php echo $direccion; ?></td>
										<td> <?php echo $correo; ?></td>
										<td> <?php echo $dpi; ?></td>
										<td> <?php echo $fecnac; ?></td>

									</tr>

								</table>
								</section>
							</body>
					    </html>
			    		<?php
			    	}
			}





?>