<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>


<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion =mysql_connect($host, $usuario, $contraseña);
	mysql_select_db($base, $conexion);

	 $consulta = mysql_query("SELECT codigo, nombre, apellido, direccion, correo, dpi, fecnac FROM empleado", $conexion) OR die ("No se pudo ejecutar la consulta1");


	if(isset($_POST['eliminar'])){ 

	$el = $_POST['eliminar'];

	try {
		foreach($el as $id){
					mysql_query("delete from empleado where codigo=".$id."",$conexion);
					header("Location: http://localhost/proyectosumg/Estaciones/vistas/empleado.php");

							
		
		}
		}
		 catch (Exception $e) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/empleado.php");
	}
	}
	


	if(isset($_POST['modificar'])){
		$mod = $_POST['modificar'];
      //  $query = "UPDATE empleado set nombre='hola' WHERE codigo=".$_POST['modificar'];
        //echo $query;
        foreach($mod as $id){

        	while ($fila = mysql_fetch_row($consulta)) {
        	    $codigo = $fila[0];
			    $nombre = $fila[1];
			    $apellido = $fila[2];
			    $direccion = $fila[3];
			    $correo = $fila[4];
			    $dpi = $fila[5];
			    $fecnac = $fila[6];

				    if ($id ===$codigo) {
				    	
				    	?>

				    	<!DOCTYPE html>
							<html>
							<head>
								<title></title>
								<link rel="stylesheet" type="text/css" href="../Formulario/css/estilo.css"/>
							</head>
							<body>
								<div class="form">
									<form action="../controladores/modificarEmpleado.php" method="POST">
										<h1>Modificar Empleado</h1>
										<label form="codigo"></label>
										<input type="text" name="codigo" placeholder="codigo" value="<?php echo $codigo;  ?>">
										<label form="nombre"></label>
										<input type="text" placeholder="Ingrese Nombre" name="nombre" value="<?php echo $nombre;  ?>">
										<label form="apellido"></label>
										<input type="text" placeholder="Ingrese apellido" name="apellido" value="<?php echo $apellido;  ?>" >
										<label form="direccion"></label>
										<input type="text" placeholder="Ingrese direccion" name="direccion" value="<?php echo $direccion;  ?>">
										<label form="correo"></label>
										<input type="text" name="correo" placeholder="Ingrese Correo" value="<?php echo $correo;  ?>">
										<label form="dpi"></label>
										<input type="text" name="dpi" placeholder="Ingrese dpi" value="<?php echo $dpi;  ?>">
										<label form="fecha"></label>
										<input type="text" name="fecha" placeholder="Ingrese fecha" value="<?php echo $fecnac;  ?>">
										<button>Enviar</button>
									</form>
								</div>						

							</body>
							</html>
				    		

				    	<?php

					}

				
			}
        
    }
    }			
?>