<?php
	if(isset($_POST['eliminar'])){
        echo "checkbox t1 seleccionado <br/>\n";
    }
    if(isset($_POST['modificar'])){
        echo "checkbox t2 seleccionado <br/>\n";
    }			//$borarempleado=$conexion->query("DELETE  FROM empleado where dpi='$id_borrar'");
				
			
?>