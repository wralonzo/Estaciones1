<?php
$conexion = mysql_connect("localhost" , "root" , "");

    if (!$conexion) {
        echo 'error';
    }
    mysql_select_db("subestaciones",$conexion);

    $id=$_POST['codigo'];
	$name=$_POST['nombre'];
	$lastname=$_POST['apellido'];
	$address=$_POST['direccion'];
	$email=$_POST['correo'];
	$dpi=$_POST['dpi'];
	$birthdate=$_POST['fecha'];
	//hacemos la sentencia sql
	//$query = "UPDATE empleado set nombre='hola' WHERE codigo=".$_POST['modificar'];

	$sql = "UPDATE empleado set nombre='$name', apellido='$lastname', direccion='$address', correo='$email', dpi='$dpi', fecnac='$birthdate' WHERE codigo='$id' ";

	//ejecutar sentencia
	$ejecutar = mysql_query($sql, $conexion);
	if (!$ejecutar) {
		header("Location: http://localhost/proyectosumg/Estaciones/Controladores/eliminar.php");
	}

	else{
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/empleado.php");
	}
	//verificar ejecucion
	



?>