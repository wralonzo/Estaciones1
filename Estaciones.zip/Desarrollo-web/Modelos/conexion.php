<?php  
	class conexion(){
      private $servidor;
      private $usuario;
      private $contraseña;
      private $basedatos;
      public  $conexion;


      public function __construct(){
         $this->$servidor = "localhost";
         $this->$usuario = "root";
         $this->$contraseña = "";
         $this->$basedatos = "subestaciones";
      }


      function conectar(){
         $this->$conexion = new mysqli_connect($servidor, $usuario, $contraseña, $basedatos);
      }


      function cerrar(){
         $this->$conexion->close();
      }

   }
 
?>  