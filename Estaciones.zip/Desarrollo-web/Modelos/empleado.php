<?php 
	class empleado
	{
		private $conexion;
		public function __construct()
		{
			require_once('conexion.php');
			$this->conexion= new conexion();
			$this->conexion->conectar();
		}

		function lista_empleado($valor)
		{
			$sql="SELECT * FROM empleado WHERE nombre like '%".$valor."%'";
			$this->conexion->conexion->set_charset('utf8');
			$resultados=$this->conexion->conexion->query($sql);
			$arreglo = array();
			while ($re=$resultados->fetch_array(MYSQL_NUM)) {
				$arreglo[]=$re;
			}
			return $arreglo;
			$this->conexion->cerrar();

		}
		function actualizar($id, $nom, $ape, $dir, $email, $dpi, $fecha,)
		{
			$sql="UPDATE empleado SET nombre='$nom', apellido='$ape', direccion='$dir', correo='$email', dpi='$dpi', fecnac='$fecha' WHERE codigo='$id'";
			if($this->conexion->conexion->query($sql))
			{
				return true;
			}

			else
			{
				return false;
			}
			$this->conexion->cerrar();
		}


		function eliminar($id){
			$sql="DELETE FROM empleado WHERE codigo='$id'";
			if($this->conexion->conexion->query($sql)){
				return true;
			}
			else{
				return false;
			}
			$this->conexion->cerrar();
		}
	}


	
?>