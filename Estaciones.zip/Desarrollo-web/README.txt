A Pen created at CodePen.io. You can find this one at https://codepen.io/colorlib/pen/rxddKy.

 Simple HTML5/CSS3 login form that also works as registration form. You can tweak this form further to use it as part of your web app, website or anything else. 