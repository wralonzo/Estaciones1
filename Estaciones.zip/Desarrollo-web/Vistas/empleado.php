<?php
$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = mysql_connect($host, $usuario, $contraseña);
mysql_select_db($base, $conexion);

$res=mysql_query("select * from empleado",$conexion);
?>  

<html>
	<head>
		<title>EMPLEADOS</title>
		<link rel="stylesheet" type="text/css" href="css/table.css"/>
		
	</head>

<body>
	<h1>Empleados</h1>



		
	<section>
		<br><button name="nuevo" class="button button3" onclick="window.location='http://localhost/proyectosumg/Estaciones/formulario/empleado_ingreso.html'"/>Nuevo Registro</button>
		
		<form  method="POST" action="../Controladores/buscarEmpleado.php">
			<label>Buscar</label>
			<input type="text" name="txtBuscar" placeholder="Ingrese DPI" required=""></input>

			<button name="Buscar" class="button button2">Buscar</button>
		</form>
			
						
		<form method="POST" action="../Controladores/eliminar.php">
			
			<table class= "table" border="3" >
				<tr>
					<th>ID</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>Direccion</th>
					<th>Correo</th>
					<th>Dpi</th>
					<th>Fecha de nacimiento</th>
					<th>Eliminar</th>
					<th>Modificar</th>
					<th>Registrar</th>
				</tr>
				<?php
				try {			
					
				
					while ($registroempleado = mysql_fetch_array($res))
					{
						echo '<tr>
								
								<td>'.$registroempleado['codigo'].'</td>
								<td>'.$registroempleado['nombre'].'</td>
								<td>'.$registroempleado['apellido'].'</td>
								<td>'.$registroempleado['direccion'].'</td>
								<td>'.$registroempleado['correo'].'</td>
								<td>'.$registroempleado['dpi'].'</td>
								<td>'.$registroempleado['fecnac'].'</td>
								<td><input type="checkbox" name="eliminar[]" value="'.$registroempleado['codigo'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registroempleado['codigo'].'"/></td>
								<td><button class="button button4" onclick="window.location="http://localhost/proyectosumg/Estaciones/formulario/empleado_ingreso.html">Registrar</button></td>
							</tr>'; 
					}

				} catch (Exception $e) { 
					header("Location: http://localhost/proyectosumg/Estaciones/vistas/empleado.php");
				}

				?>
			</table>
				
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
		
		
		</form>		
	</section>

	</body>
</html>